$('.add-button').on('click', function(e)
{
    e.preventDefault()
    let quantity = Number($(this).closest('div').find('input').val());
    $(this).closest('div').find('input').val(quantity + 1);
});

$('.remove-button').on('click', function(e)
{
    e.preventDefault()
    let quantity = Number($(this).closest('div').find('input').val());
    if(quantity != 0)
    {
        $(this).closest('div').find('input').val(quantity - 1);
    }
});