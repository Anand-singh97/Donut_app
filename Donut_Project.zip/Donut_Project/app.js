import express from 'express';
import bodyParser from 'body-parser';
import {body, check, validationResult} from 'express-validator';

//Express application made
const app = express();

//View Engine for rendering ejs template.
app.set('view engine', 'ejs');

//Serve static files from public directory.
app.use(express.static('public'));
app.set('View', 'views');
app.use(bodyParser.urlencoded({ extended: true }));

const itemName = ['Vanilla Bean Glazed', 'Cinnamon Sugar Ring', 'Pink Sprinkle', 'Blue Unicorn', 'Oreo', 'Strawberry Rhubarb'];
const keyForItems = ['item1', 'item2', 'item3', 'item4', 'item5', 'item6'];
const itemPrice = [5, 7, 10, 7, 5, 10];
let quantity = [];

const canadaProvinces = ["AB", "BC", "MB", "NB", "NL", "NS", "ON", "PE", "QC", "SK"];
const taxRates = [0.05, 0.07, 0.08, 0.15, 0.15, 0.10, 0.13, 0.09, 0.09975, 0.06];

//Record all the errors.
let errors = [];

//At least one item is selected.
let isQuantityValid = false;

function checkQuantity(req)
{
    quantity = [];
    isQuantityValid = false;
    errors = [];
    keyForItems.forEach(function(item){
      
        let userInput = req.body[item];

        if(userInput != 0)
        {
            isQuantityValid = true;
        }

        quantity.push(userInput);
    })
    console.log(quantity);
}

function calculateTotal()
{
    let total = 0;
    for(let i = 0; i < quantity.length; i++)
    {
        total += quantity[i] * itemPrice[i];
    }

    return total;
}

app.post('/submit',
[
    check('firstName', 'Invalid firstName').notEmpty(),
    check('lastName', 'Invalid lastName').notEmpty(),
    check('address', 'Invalid address').notEmpty(),
    check('country', 'Invalid Country input').notEmpty(),
    check('postalCode').matches(/^[A-Za-z]\d[A-Za-z] \d[A-Za-z]\d$/).withMessage('Invalid Postal Code')
],
 (req,res)=>{

    checkQuantity(req);
    let total = calculateTotal();

    let errorsArray = validationResult(req).array();

    errorsArray.forEach((error)=>{
        errors.push(error.msg);
    });

    if(isQuantityValid)
    {
        res.render('checkout.ejs', {
            itemName:itemName,
            quantity:quantity,
            itemPrice:itemPrice,
            total:total
        });
    }
});

app.get('/', (req, res) =>{
    res.render('index.ejs')
});

const port = 3003
app.listen(port, ()=>{
    console.log(`Server set at port ${port}`);
});













